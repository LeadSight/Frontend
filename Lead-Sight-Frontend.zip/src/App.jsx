import React from "react";
import { Routes, Route } from "react-router-dom";
import LoginPage from "./pages/LoginPage";
import ForgotPasswordPage from "./pages/ForgotPasswordPage";
import ResetPasswordPage from "./pages/ResetPasswordPage";
import DashboardPage from "./pages/DashboardPage";
import ProtectedRoute from "./components/ProtectedRoute";

function App() {
    return(
        <>
            <Routes>
                <Route
                    path='/login'
                    element={ <LoginPage/> }
                />
                <Route
                    path='/forgot-password'
                    element={ <ForgotPasswordPage/> }
                />
                <Route
                    path='/reset-password'
                    element={ <ResetPasswordPage/> }
                />
                <Route element={<ProtectedRoute/>}>
                    <Route
                        path="/" 
                        element={ <DashboardPage />
                        }
                    />
                </Route>
            </Routes>
        </>
    );
}

export default App;