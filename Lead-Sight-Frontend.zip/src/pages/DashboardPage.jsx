import { useAuth } from "../hooks/useAuth";
import { logout } from "../utils/api";
import { useNavigate } from "react-router-dom";

function DashboardPage() {
    const navigate = useNavigate();
    const { user } = useAuth();

    function onLogout() {
        logout();

        navigate('/login');
    }
    
    return (
        <>
            <h2>HELLO {user}</h2>
            <button onClick={ onLogout } >Logout</button>
        </>
    )
}

export default DashboardPage;